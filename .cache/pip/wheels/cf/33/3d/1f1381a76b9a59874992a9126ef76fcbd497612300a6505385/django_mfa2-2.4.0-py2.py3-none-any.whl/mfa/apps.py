from django.apps import AppConfig
class myAppNameConfig(AppConfig):
    name = 'mfa'
    verbose_name = 'A Much Better Name'