Main contributors
-----------------
- Hideo Hattori (https://github.com/hhatto)
- Steven Myint (https://github.com/myint)
- Bill Wendling (https://github.com/gwelymernans)

Patches
-------
- Fraser Tweedale (https://github.com/frasertweedale)
- clach04 (https://github.com/clach04)
- Marc Abramowitz (https://github.com/msabramo)
- dellis23 (https://github.com/dellis23)
- Sam Vilain (https://github.com/samv)
- Florent Xicluna (https://github.com/florentx)
- Andras Tim (https://github.com/andras-tim)
- tomscytale (https://github.com/tomscytale)
- Filip Noetzel (https://github.com/peritus)
- Erik Bray (https://github.com/iguananaut)
- Christopher Medrela (https://github.com/chrismedrela)
- 小明 (https://github.com/dongweiming)
- Andy Hayden (https://github.com/hayd)
- Fabio Zadrozny (https://github.com/fabioz)
- Alex Chernetz (https://github.com/achernet)
- Marc Schlaich (https://github.com/schlamar)
